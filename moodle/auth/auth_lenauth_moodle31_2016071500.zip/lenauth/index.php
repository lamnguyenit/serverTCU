<?php
 die( 'silence is golden' );