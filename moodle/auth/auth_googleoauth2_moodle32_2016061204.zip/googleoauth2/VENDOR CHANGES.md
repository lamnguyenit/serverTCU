List here the hacks that need to be done in the 'vendor' folder.

* class Depotwarehouse\OAuth2\Client\ProviderBattleNet
=> change battle.net urls: us to eu (if you want to use the european server of course).

* pixelfear/oauth2-dropbox
=> nothing to do, just saying that I actually use a personal fork of this rep where I changed the require version of League oauth2.
