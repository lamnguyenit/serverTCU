<?php

namespace Aws\WorkSpaces\Exception;

use Aws\Common\Exception\ServiceResponseException;

/**
 * Default service exception class
 */
class WorkSpacesException extends ServiceResponseException {}
