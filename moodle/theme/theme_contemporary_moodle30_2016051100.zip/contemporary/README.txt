Contemporary 
============
Moodle theme.
Contemporary is a fluid-width, three-column theme for Moodle 2.x. 
It has a crisp and sophisticated look, and a setting page
where you can change your custom banner, link color, footer text and add custom CSS.

New Option
-----------
1 - MENU BAND COLOR
2 - MENU ITEM - FONT & BACKGROUND
3 - MENU ITEM : HOVER - BACKGROUND
4 - BLOCK - HEADER BAND COLOR
5 - BLOCK - HEADER FONT COLOR

Customization using custom theme settings
-----------------------------------------
The settings page for the Contemporary theme can be located by navigating to:
Administration > Site Administration > Appearance > Themes > Contemporary

Theme documentation
--------------------
Further information can be found on 3i Logic website.
http://3ilogic.com/plugindoc/Contemporary.pdf