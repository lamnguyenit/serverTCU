This version updates the Rocket to the latest requirements of 2.5 to 2.9
